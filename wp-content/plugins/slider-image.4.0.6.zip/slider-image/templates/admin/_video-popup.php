<div>
    <div>
        <span class="buy-pro"><?php _e('This feature is disabled in free version', 'hugeit-slider'); ?>. <br><?php _e('If you need this functionality, you need to', 'hugeit-slider'); ?> <a href="https://huge-it.com/slider/" target="_blank"><?php _e('buy the commercial version', 'hugeit-slider'); ?></a>.</span>
    </div>
	<h3><?php _e('Add Video URL From Youtube or Vimeo', 'hugeit-slider'); ?></h3>
	<div>
		<input type="text" id="hugeit_slider_video_popup_url" style="width: 80%" />
		<input type="button" value="<?php _e('Insert Video Slide', 'hugeit-slider'); ?>" class="button-primary" disabled="disabled" id="hugeit_slider_add_video_slide_button" />
	</div>
</div>